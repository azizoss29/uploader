document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const uploadForm = document.getElementById('uploadForm');
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadFeedback = document.getElementById('uploadFeedback');
    const startBtn = document.getElementById('startBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const resumeBtn = document.getElementById('resumeBtn');
    const stopBtn = document.getElementById('stopBtn');
    const progressSection = document.getElementById('progressSection');
    const progressBar = document.getElementById('progressBar');
    const totalCount = document.getElementById('totalCount');
    const currentCount = document.getElementById('currentCount');
    const successCount = document.getElementById('successCount');
    const failedCount = document.getElementById('failedCount');
    const statusText = document.getElementById('statusText');
    const currentProduct = document.getElementById('currentProduct');
    const errorSection = document.getElementById('errorSection');
    const errorLog = document.getElementById('errorLog');

    // Status polling interval
    let statusInterval = null;

    // Function to create the image upload container
    function createImageUploader(imagePaths) {
        // Create container for image uploads if it doesn't exist
        let imageUploadContainer = document.getElementById('imageUploadContainer');
        if (!imageUploadContainer) {
            imageUploadContainer = document.createElement('div');
            imageUploadContainer.id = 'imageUploadContainer';
            imageUploadContainer.className = 'mt-4';
            document.getElementById('uploadFeedback').after(imageUploadContainer);
        }
        
        // Clear any existing content
        imageUploadContainer.innerHTML = '';
        
        // Create header
        const header = document.createElement('h5');
        header.textContent = 'Upload Your Product Images';
        imageUploadContainer.appendChild(header);
        
        // Create description
        const description = document.createElement('p');
        description.textContent = 'These images will be used instead of the local paths in your spreadsheet.';
        imageUploadContainer.appendChild(description);
        
        // Create a radio group for image mode selection
        const modeContainer = document.createElement('div');
        modeContainer.className = 'mb-3';
        
        const modeLabel = document.createElement('div');
        modeLabel.className = 'mb-2';
        modeLabel.textContent = 'Image Source:';
        modeContainer.appendChild(modeLabel);
        
        const localRadioDiv = document.createElement('div');
        localRadioDiv.className = 'form-check';
        
        const localRadio = document.createElement('input');
        localRadio.className = 'form-check-input';
        localRadio.type = 'radio';
        localRadio.name = 'imageMode';
        localRadio.id = 'localImageMode';
        localRadio.value = 'local';
        localRadio.checked = true;
        
        const localLabel = document.createElement('label');
        localLabel.className = 'form-check-label';
        localLabel.htmlFor = 'localImageMode';
        localLabel.textContent = 'Use local paths from spreadsheet (only works when running locally)';
        
        localRadioDiv.appendChild(localRadio);
        localRadioDiv.appendChild(localLabel);
        modeContainer.appendChild(localRadioDiv);
        
        const uploadRadioDiv = document.createElement('div');
        uploadRadioDiv.className = 'form-check';
        
        const uploadRadio = document.createElement('input');
        uploadRadio.className = 'form-check-input';
        uploadRadio.type = 'radio';
        uploadRadio.name = 'imageMode';
        uploadRadio.id = 'uploadImageMode';
        uploadRadio.value = 'upload';
        
        const uploadLabel = document.createElement('label');
        uploadLabel.className = 'form-check-label';
        uploadLabel.htmlFor = 'uploadImageMode';
        uploadLabel.textContent = 'Upload images (recommended for web use)';
        
        uploadRadioDiv.appendChild(uploadRadio);
        uploadRadioDiv.appendChild(uploadLabel);
        modeContainer.appendChild(uploadRadioDiv);
        
        imageUploadContainer.appendChild(modeContainer);
        
        // Create image upload list container (hidden initially)
        const imageListContainer = document.createElement('div');
        imageListContainer.id = 'imageListContainer';
        imageListContainer.style.display = 'none';
        imageUploadContainer.appendChild(imageListContainer);
        
        // Create list of image upload elements
        const imageList = document.createElement('div');
        imageList.className = 'list-group mb-3';
        imagePaths.forEach((path, index) => {
            const item = document.createElement('div');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            item.dataset.path = path;
            item.dataset.index = index;
            
            // Original path display
            const pathText = document.createElement('small');
            pathText.className = 'text-truncate me-3';
            pathText.style.maxWidth = '250px';
            pathText.textContent = path;
            item.appendChild(pathText);
            
            // Upload button + status
            const uploadGroup = document.createElement('div');
            
            const uploadBtn = document.createElement('button');
            uploadBtn.className = 'btn btn-sm btn-primary';
            uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Upload';
            uploadBtn.onclick = function() {
                const fileInput = document.createElement('input');
                fileInput.type = 'file';
                fileInput.accept = 'image/*';
                fileInput.onchange = function() {
                    if (fileInput.files.length > 0) {
                        uploadImage(fileInput.files[0], index, path, uploadBtn);
                    }
                };
                fileInput.click();
            };
            
            uploadGroup.appendChild(uploadBtn);
            item.appendChild(uploadGroup);
            
            imageList.appendChild(item);
        });
        
        imageListContainer.appendChild(imageList);
        
        // Add event listeners for the radio buttons
        localRadio.addEventListener('change', function() {
            if (this.checked) {
                imageListContainer.style.display = 'none';
            }
        });
        
        uploadRadio.addEventListener('change', function() {
            if (this.checked) {
                imageListContainer.style.display = 'block';
            }
        });
    }
    
    // Function to upload an individual image
    function uploadImage(file, index, originalPath, button) {
        // Change button to loading state
        const originalButton = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
        
        const formData = new FormData();
        formData.append('image', file);
        formData.append('index', index);
        formData.append('original_path', originalPath);
        
        fetch('/upload_image', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-exclamation-circle me-1"></i> Error';
                button.className = 'btn btn-sm btn-danger';
                console.error(data.error);
            } else {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-check me-1"></i> Uploaded';
                button.className = 'btn btn-sm btn-success';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-exclamation-circle me-1"></i> Error';
            button.className = 'btn btn-sm btn-danger';
        });
    }

    // Handle file upload form submission
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const fileInput = document.getElementById('spreadsheetFile');
        if (fileInput.files.length === 0) {
            showFeedback('error', 'Please select a file to upload.');
            return;
        }
        
        const file = fileInput.files[0];
        const formData = new FormData();
        formData.append('file', file);
        
        // Disable the upload button and show loading state
        uploadBtn.disabled = true;
        uploadBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
        
        // Send the file to the server
        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showFeedback('error', data.error);
                uploadBtn.disabled = false;
                uploadBtn.innerHTML = '<i class="fas fa-upload me-2"></i>Upload Spreadsheet';
            } else {
                showFeedback('success', data.message);
                startBtn.disabled = false;
                // Update total count display
                totalCount.textContent = data.count;
                
                // Create image upload section if image paths are available
                if (data.image_paths && data.image_paths.length > 0) {
                    createImageUploader(data.image_paths);
                }
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showFeedback('error', 'An error occurred while uploading the file.');
            uploadBtn.disabled = false;
            uploadBtn.innerHTML = '<i class="fas fa-upload me-2"></i>Upload Spreadsheet';
        });
    });
    
    // Handle start upload button
    startBtn.addEventListener('click', function() {
        const configForm = document.getElementById('configForm');
        const formData = new FormData(configForm);
        
        // Get image mode selection
        const imageMode = document.querySelector('input[name="imageMode"]:checked')?.value || 'local';
        
        const config = {
            headless: formData.get('headless') === 'on',
            delay: parseInt(formData.get('delay'), 10) || 2,
            image_mode: imageMode
        };
        
        fetch('/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(config)
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showFeedback('error', data.error);
            } else {
                // Show progress section
                progressSection.classList.remove('d-none');
                errorSection.classList.add('d-none');
                
                // Update UI state
                startBtn.disabled = true;
                pauseBtn.disabled = false;
                stopBtn.disabled = false;
                
                // Start polling for status updates
                startStatusPolling();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showFeedback('error', 'An error occurred while starting the upload process.');
        });
    });
    
    // Handle pause button
    pauseBtn.addEventListener('click', function() {
        fetch('/pause', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showFeedback('error', data.error);
            } else {
                pauseBtn.disabled = true;
                resumeBtn.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showFeedback('error', 'An error occurred while pausing the upload.');
        });
    });
    
    // Handle resume button
    resumeBtn.addEventListener('click', function() {
        fetch('/resume', {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                showFeedback('error', data.error);
            } else {
                pauseBtn.disabled = false;
                resumeBtn.disabled = true;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showFeedback('error', 'An error occurred while resuming the upload.');
        });
    });
    
    // Handle stop button
    stopBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to stop the upload process? This cannot be resumed.')) {
            fetch('/stop', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showFeedback('error', data.error);
                } else {
                    pauseBtn.disabled = true;
                    resumeBtn.disabled = true;
                    stopBtn.disabled = true;
                    startBtn.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showFeedback('error', 'An error occurred while stopping the upload.');
            });
        }
    });
    
    // Function to display feedback messages
    function showFeedback(type, message) {
        uploadFeedback.classList.remove('d-none', 'alert-success', 'alert-danger');
        
        if (type === 'success') {
            uploadFeedback.classList.add('alert', 'alert-success');
        } else {
            uploadFeedback.classList.add('alert', 'alert-danger');
        }
        
        uploadFeedback.textContent = message;
    }
    
    // Function to start polling for status updates
    function startStatusPolling() {
        // Clear any existing interval
        if (statusInterval) {
            clearInterval(statusInterval);
        }
        
        // Poll for status every second
        statusInterval = setInterval(fetchStatus, 1000);
    }
    
    // Function to fetch the current upload status
    function fetchStatus() {
        fetch('/status')
            .then(response => response.json())
            .then(data => {
                updateStatusUI(data);
            })
            .catch(error => {
                console.error('Error fetching status:', error);
            });
    }
    
    // Function to update the UI with status information
    function updateStatusUI(data) {
        // Update counters
        totalCount.textContent = data.total;
        currentCount.textContent = data.current;
        successCount.textContent = data.success;
        failedCount.textContent = data.failed;
        
        // Update status text with proper formatting
        let statusClass = '';
        let statusDisplay = '';
        
        switch (data.status) {
            case 'idle':
                statusDisplay = 'Idle';
                statusClass = 'text-secondary';
                break;
            case 'running':
                statusDisplay = 'Running';
                statusClass = 'text-success';
                break;
            case 'paused':
                statusDisplay = 'Paused';
                statusClass = 'text-warning';
                break;
            case 'completed':
                statusDisplay = 'Completed';
                statusClass = 'text-info';
                stopStatusPolling();
                resetControls();
                break;
            case 'stopped':
                statusDisplay = 'Stopped';
                statusClass = 'text-danger';
                stopStatusPolling();
                resetControls();
                break;
            case 'error':
                statusDisplay = 'Error';
                statusClass = 'text-danger';
                stopStatusPolling();
                resetControls();
                break;
            default:
                statusDisplay = data.status;
                statusClass = 'text-secondary';
        }
        
        statusText.textContent = statusDisplay;
        statusText.className = statusClass;
        
        // Update current product
        currentProduct.textContent = data.current_product || 'None';
        
        // Update progress bar
        if (data.total > 0) {
            const percent = Math.round((data.current / data.total) * 100);
            progressBar.style.width = `${percent}%`;
            progressBar.textContent = `${percent}%`;
            progressBar.setAttribute('aria-valuenow', percent);
        }
        
        // Update error log if there are errors
        if (data.errors && data.errors.length > 0) {
            errorSection.classList.remove('d-none');
            updateErrorLog(data.errors);
        }
        
        // Update button states based on current status
        updateButtonStates(data.status);
    }
    
    // Function to update the error log table
    function updateErrorLog(errors) {
        errorLog.innerHTML = '';
        
        errors.forEach(error => {
            const row = document.createElement('tr');
            
            const productCell = document.createElement('td');
            productCell.textContent = error.product;
            
            const titleCell = document.createElement('td');
            titleCell.textContent = error.title;
            
            const errorCell = document.createElement('td');
            errorCell.textContent = error.error;
            
            row.appendChild(productCell);
            row.appendChild(titleCell);
            row.appendChild(errorCell);
            
            errorLog.appendChild(row);
        });
    }
    
    // Function to update button states based on status
    function updateButtonStates(status) {
        switch (status) {
            case 'running':
                pauseBtn.disabled = false;
                resumeBtn.disabled = true;
                stopBtn.disabled = false;
                startBtn.disabled = true;
                break;
            case 'paused':
                pauseBtn.disabled = true;
                resumeBtn.disabled = false;
                stopBtn.disabled = false;
                startBtn.disabled = true;
                break;
            case 'completed':
            case 'stopped':
            case 'error':
                pauseBtn.disabled = true;
                resumeBtn.disabled = true;
                stopBtn.disabled = true;
                startBtn.disabled = false;
                break;
        }
    }
    
    // Function to stop the status polling
    function stopStatusPolling() {
        if (statusInterval) {
            clearInterval(statusInterval);
            statusInterval = null;
        }
    }
    
    // Function to reset control buttons
    function resetControls() {
        pauseBtn.disabled = true;
        resumeBtn.disabled = true;
        stopBtn.disabled = true;
        startBtn.disabled = false;
    }
});
