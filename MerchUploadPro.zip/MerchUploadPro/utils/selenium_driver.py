import os
import time
import logging
import sys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# Import chromedriver-py to get the path to the chromedriver executable
from chromedriver_py import binary_path

class MerchAutomation:
    """
    Class to handle Amazon Merch automation using Selenium
    """
    
    def __init__(self, headless=False):
        """Initialize the automation driver"""
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Initializing Selenium driver (headless: {headless})")
        
        # Set up Chrome options
        chrome_options = Options()
        if headless:
            chrome_options.add_argument("--headless=new")
        
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        
        # Log the binary path
        self.logger.info(f"ChromeDriver binary path: {binary_path}")
        
        # Create a Chrome service with the binary path from chromedriver-py
        chrome_service = Service(executable_path=binary_path)
        
        # Create a new Chrome driver
        try:
            self.driver = webdriver.Chrome(service=chrome_service, options=chrome_options)
            self.driver.maximize_window()
            self.logger.info("Chrome driver initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize Chrome driver: {str(e)}")
            raise Exception(f"Failed to initialize Chrome driver: {str(e)}")

    def upload_product(self, product):
        """
        Upload a single product to Amazon Merch
        
        Args:
            product (dict): Dictionary containing product details
        """
        try:
            # Navigate to the Merch by Amazon upload page
            self.logger.info(f"Navigating to upload page for product: {product.get('title')}")
            self.driver.get("https://merch.amazon.com/designs/new")
            
            # Wait for the page to load
            self.wait_for_element_presence(By.ID, "dark-merch-header-logo", 30)
            
            # Fill in the form fields
            self.logger.info("Filling in product details")
            
            # Upload the product image
            self.upload_image(product["image_path"])
            
            # Fill in the product title
            self.fill_input_field("name", product["title"])
            
            # Fill in the brand
            self.fill_input_field("brand", product["brand"])
            
            # Fill in bullet points if provided
            if product.get("bullet_point_1"):
                self.fill_textarea_field("bulletPoint1", product["bullet_point_1"])
            
            if product.get("bullet_point_2"):
                self.fill_textarea_field("bulletPoint2", product["bullet_point_2"])
            
            # Fill in description if provided
            if product.get("description"):
                self.fill_textarea_field("description", product["description"])
            
            # Wait for the publish button to be enabled (design is ready)
            self.logger.info("Waiting for the design to be ready and publish button to be enabled")
            self.wait_for_element_presence(By.XPATH, "//button[contains(text(), 'Publish') and not(@disabled)]", 60)
            
            # Click the publish button
            publish_button = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Publish') and not(@disabled)]")
            self.logger.info("Design is ready. Clicking publish button.")
            publish_button.click()
            
            # Wait for the confirmation dialog to appear
            self.logger.info("Waiting for confirmation dialog")
            self.wait_for_element_presence(By.XPATH, "//div[contains(@class, 'modal-dialog')]", 30)
            
            # Find and click the Publish button in the modal dialog using its class
            self.logger.info("Looking for Publish button in confirmation dialog")
            confirm_button = self.driver.find_element(By.XPATH, "//div[contains(@class, 'modal-footer')]//button[contains(@class, 'btn-primary') or contains(@class, 'btn-submit')]")
            self.logger.info("Clicking Publish button in confirmation dialog")
            confirm_button.click()
            
            # Wait for success message or next page
            success = self.wait_for_success()
            
            if not success:
                raise Exception("Failed to verify successful submission")
            
            self.logger.info(f"Successfully uploaded product: {product.get('title')}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error uploading product: {str(e)}")
            raise Exception(f"Error uploading product: {str(e)}")

    def upload_image(self, image_path):
        """
        Upload the product image
        
        Args:
            image_path (str): Path to the image file
        """
        try:
            self.logger.info(f"Uploading image: {image_path}")
            
            # Verify that the image file exists
            if not os.path.exists(image_path):
                raise Exception(f"Image file not found: {image_path}")
            
            # Find the file input element
            file_input = self.driver.find_element(By.XPATH, "//input[@type='file']")
            
            # Send the file path to the input element
            file_input.send_keys(image_path)
            
            # Wait for the image to be uploaded
            self.wait_for_element_presence(By.XPATH, "//div[contains(@class, 'image-uploaded')]", 20)
            
            self.logger.info("Image uploaded successfully")
            
        except Exception as e:
            self.logger.error(f"Error uploading image: {str(e)}")
            raise Exception(f"Error uploading image: {str(e)}")

    def fill_input_field(self, field_id, value):
        """
        Fill an input field
        
        Args:
            field_id (str): ID of the input field
            value (str): Value to enter
        """
        try:
            input_field = self.driver.find_element(By.ID, field_id)
            input_field.clear()
            input_field.send_keys(value)
            self.logger.debug(f"Filled input field {field_id} with value: {value}")
        except NoSuchElementException:
            # Try using name selector if ID doesn't work
            try:
                input_field = self.driver.find_element(By.NAME, field_id)
                input_field.clear()
                input_field.send_keys(value)
                self.logger.debug(f"Filled input field {field_id} with value: {value}")
            except NoSuchElementException:
                raise Exception(f"Could not find input field with ID or name: {field_id}")

    def fill_textarea_field(self, field_id, value):
        """
        Fill a textarea field
        
        Args:
            field_id (str): ID of the textarea field
            value (str): Value to enter
        """
        try:
            textarea = self.driver.find_element(By.ID, field_id)
            textarea.clear()
            textarea.send_keys(value)
            self.logger.debug(f"Filled textarea field {field_id} with value: {value}")
        except NoSuchElementException:
            # Try using name selector if ID doesn't work
            try:
                textarea = self.driver.find_element(By.NAME, field_id)
                textarea.clear()
                textarea.send_keys(value)
                self.logger.debug(f"Filled textarea field {field_id} with value: {value}")
            except NoSuchElementException:
                raise Exception(f"Could not find textarea field with ID or name: {field_id}")

    def wait_for_element_presence(self, by, value, timeout=10):
        """
        Wait for an element to be present
        
        Args:
            by (selenium.webdriver.common.by.By): Type of selector
            value (str): Value of the selector
            timeout (int): Timeout in seconds
            
        Returns:
            bool: True if the element is found, False otherwise
        """
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            return True
        except TimeoutException:
            self.logger.warning(f"Timed out waiting for element: {value}")
            return False

    def wait_for_success(self):
        """
        Wait for a success message after submission
        
        Returns:
            bool: True if success is detected, False otherwise
        """
        try:
            # Wait for either a success message, confirmation text, or dashboard redirection
            self.logger.info("Waiting for success confirmation")
            
            # Try different success indicators
            for _ in range(30):  # Try for 30 seconds
                try:
                    # Look for success message
                    success_element = self.driver.find_element(By.XPATH, "//div[contains(text(), 'Success')]")
                    if success_element:
                        self.logger.info("Success message found")
                        return True
                except NoSuchElementException:
                    pass
                
                try:
                    # Look for confirmation text
                    confirmation = self.driver.find_element(By.XPATH, "//div[contains(text(), 'has been submitted')]")
                    if confirmation:
                        self.logger.info("Submission confirmation found")
                        return True
                except NoSuchElementException:
                    pass
                
                # Check URL for dashboard
                if "dashboard" in self.driver.current_url:
                    self.logger.info("Redirected to dashboard")
                    return True
                    
                # Wait a bit before trying again
                time.sleep(1)
            
            # If we've reached here, no success indicator was found
            self.logger.warning("No success confirmation detected after 30 seconds")
            return False
            
        except Exception as e:
            self.logger.warning(f"Error waiting for success confirmation: {str(e)}")
            return False

    def close(self):
        """Close the browser and clean up resources"""
        self.logger.info("Closing the browser")
        if hasattr(self, 'driver'):
            self.driver.quit()
