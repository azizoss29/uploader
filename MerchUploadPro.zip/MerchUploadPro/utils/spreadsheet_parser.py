import os
import pandas as pd
import logging
from openpyxl import load_workbook

def parse_spreadsheet(file_path):
    """
    Parse a spreadsheet file (CSV, XLSX, XLS) and extract product data
    
    Args:
        file_path (str): Path to the spreadsheet file
        
    Returns:
        list: List of dictionaries containing product data
    """
    logger = logging.getLogger(__name__)
    logger.info(f"Parsing spreadsheet: {file_path}")
    
    # Check if the file exists
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    # Determine file type based on extension
    file_extension = os.path.splitext(file_path)[1].lower()
    
    try:
        # Parse the file based on its type
        if file_extension == '.csv':
            df = pd.read_csv(file_path)
        elif file_extension in ['.xlsx', '.xls']:
            df = pd.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_extension}")
        
        # Verify required and optional columns
        required_columns = ['title', 'brand', 'image_path']
        optional_columns = ['bullet_point_1', 'bullet_point_2', 'description']
        
        # Check for required columns
        missing_required = [col for col in required_columns if col not in df.columns]
        if missing_required:
            raise ValueError(f"Missing required columns in spreadsheet: {', '.join(missing_required)}")
        
        # Add optional columns with empty values if they're missing
        for col in optional_columns:
            if col not in df.columns:
                df[col] = ""
        
        # Convert DataFrame to list of dictionaries
        products = df.to_dict(orient='records')
        
        # Validate each product
        for i, product in enumerate(products):
            # Check for missing required values
            for col in required_columns:
                if pd.isna(product[col]) or not product[col]:
                    raise ValueError(f"Row {i+1}: Missing required value for '{col}'")
            
            # Ensure optional fields are not None
            for col in optional_columns:
                if pd.isna(product[col]):
                    product[col] = ""
            
            # Don't verify image paths - they'll be uploaded separately
            # Just make sure the path is not empty
            image_path = product['image_path']
            if not image_path:
                raise ValueError(f"Row {i+1}: Empty image_path field")
        
        logger.info(f"Successfully parsed {len(products)} products from spreadsheet")
        return products
    
    except Exception as e:
        logger.error(f"Error parsing spreadsheet: {str(e)}")
        raise ValueError(f"Error parsing spreadsheet: {str(e)}")
